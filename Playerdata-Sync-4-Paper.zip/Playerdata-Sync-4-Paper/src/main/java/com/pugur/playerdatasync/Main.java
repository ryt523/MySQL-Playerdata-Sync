package com.pugur.playerdatasync;

import com.destroystokyo.paper.event.server.ServerExceptionEvent;
import de.tr7zw.nbtapi.NBT;
import de.tr7zw.nbtapi.iface.ReadWriteNBT;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.*;
import java.util.Objects;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Main extends JavaPlugin implements Listener {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/minecraft";

    private static final String USER = "user";

    private static final String PASSWORD = "sqlpass_r38qCDCJL8";

    private static final BlockingQueue<Runnable> queryQueue = new LinkedBlockingQueue<>();


    @Override
    public void onEnable() {
        getLogger().info("Paper Playerdata Sync is enabled🔥");
        getServer().getPluginManager().registerEvents(this, this);

        new Thread(() -> {
            while (true) {
                try {
                    Runnable query = queryQueue.take();
                    query.run();
                } catch (InterruptedException e) {
                    getLogger().severe("Error while processing query: " + e.getMessage());
                }
            }
        }).start();
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) throws InterruptedException {
        loadPlayerDataFromDatabase(event.getPlayer());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        savePlayerDataToDatabase(event.getPlayer());
    }

    @EventHandler
    public void onServerException(ServerExceptionEvent event) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            savePlayerDataToDatabase(player);
        }
    }

    @EventHandler
    public void onServerShutdown(ServerExceptionEvent event) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            savePlayerDataToDatabase(player);
        }
    }

    public void savePlayerDataToDatabase(Player player) {
        try {
            queryQueue.put(() -> {
        try {
            Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
            String sql = "INSERT INTO playerdata (uuid, inventory, enderitems, selecteditemslot) " +
                    "VALUES (?, ?, ?, ?) " +
                    "ON DUPLICATE KEY UPDATE " +
                    "inventory = VALUES(inventory), enderitems = VALUES(enderitems), selecteditemslot = VALUES(selecteditemslot)";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, player.getUniqueId().toString());
                statement.setString(2, getPlayerInventory(player));
                statement.setString(3, getPlayerEnderitems(player));
                statement.setInt(4, player.getInventory().getHeldItemSlot());
                statement.executeUpdate();
                getLogger().info("🔥 " + player.getName() + " saved playerdata to mysql");
            }
            connection.close();
        } catch (SQLException e) {
            getLogger().severe("Error while saving playerdata to database: " + e.getMessage());
        }
            });
        } catch (InterruptedException e) {
            getLogger().severe("Error while queuing query: " + e.getMessage());
        }
    }

    public void loadPlayerDataFromDatabase(Player player) throws InterruptedException {
        Thread.sleep(500);
        try {
            queryQueue.put(() -> {
        try {
            Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
            String sql = "SELECT inventory, enderitems, selecteditemslot FROM playerdata WHERE uuid = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, player.getUniqueId().toString());

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        setPlayerInventory(player, resultSet.getString("inventory"));
                        setPlayerEnderItems(player, resultSet.getString("enderitems"));
                        int selectedSlot = resultSet.getInt("selecteditemslot");
                        player.getInventory().setHeldItemSlot(selectedSlot);
                        player.updateInventory();
                        getLogger().info("🔥 " + player.getName() + " loaded playerdata from mysql");
                        Component formattedMessage = Component.text().append
                                        (Component.text("Paper プレイヤーデータ共有 : ", NamedTextColor.AQUA)).append
                                        (Component.text("完了", NamedTextColor.GREEN))
                                .build();
                        player.sendMessage(formattedMessage);
                    }
                }
            }
            connection.close();
        } catch (SQLException e) {
            getLogger().severe("Error while loading playerdata from database: " + e.getMessage());
        }
            });
        } catch (InterruptedException e) {
            getLogger().severe("Error while queuing query: " + e.getMessage());
        }
    }

    public String getPlayerInventory(Player player) {
        Inventory inventory = player.getInventory();
        ItemStack[] itemStack = inventory.getContents();
        ReadWriteNBT nbt = NBT.itemStackArrayToNBT(itemStack);
        String inventoryString = String.valueOf(nbt);
        inventoryString = inventoryString.replace("Slot:36", "Slot:100")
                .replace("Slot:37", "Slot:101")
                .replace("Slot:38", "Slot:102")
                .replace("Slot:39", "Slot:103")
                .replace("Slot:40", "Slot:-106");
        return formatString(inventoryString);
    }

    public String getPlayerEnderitems(Player player) {
        Inventory enderitems = player.getEnderChest();
        ItemStack[] itemStack = enderitems.getContents();
        ReadWriteNBT nbt = NBT.itemStackArrayToNBT(itemStack);
        String enderitemsString = String.valueOf(nbt);
        return formatString(enderitemsString);
    }

    public String formatString(String string) {
        String formattedString;
        try {
            String beginStr = "[";
            int beginIndex = string.indexOf(beginStr);
            String endStr = ",size";
            int endIndex = string.indexOf(endStr);
            formattedString = string.substring(beginIndex, endIndex);
        } catch (Exception ignored) {
            formattedString = "[]";
        }
        return formattedString;
    }

    public static void setPlayerInventory(Player player, String inventoryString){
        inventoryString = inventoryString.replace("Slot:100", "Slot:36")
                .replace("Slot:101", "Slot:37")
                .replace("Slot:102", "Slot:38")
                .replace("Slot:103", "Slot:39")
                .replace("Slot:-106", "Slot:40");
        inventoryString = "{items:" + inventoryString + ",size:41}";
        ReadWriteNBT nbt = NBT.parseNBT(inventoryString);
        ItemStack[] itemStack = NBT.itemStackArrayFromNBT(nbt);
        Inventory inventory = player.getInventory();
        inventory.setContents(Objects.requireNonNull(itemStack));
    }

    public static void setPlayerEnderItems(Player player, String enderitemsString){
        enderitemsString = "{items:" + enderitemsString + ",size:27}";
        ReadWriteNBT nbt = NBT.parseNBT(enderitemsString);
        ItemStack[] itemStack = NBT.itemStackArrayFromNBT(nbt);
        Inventory enderChest = player.getEnderChest();
        enderChest.setContents(Objects.requireNonNull(itemStack));
    }
}
